A modification/conversion to turn Prusa MMU or Prusa Mini components into small CoreXY machines that mimic the look of the Prusa XL.

* Not an official Prusa project or product! *

Work in progress, check back later!

Prusa M (MK3/MK4 sized) coming soon!